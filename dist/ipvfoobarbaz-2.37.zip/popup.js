/*
Copyright (C) 2011  Paul Marks  http://www.pmarks.net/
Copyright (C) 2024  ziad87      https://ziad87.net/

Licensed under the Apache License, Version 2.0 (the "License");
you may not use this file except in compliance with the License.
You may obtain a copy of the License at

    http://www.apache.org/licenses/LICENSE-2.0

Unless required by applicable law or agreed to in writing, software
distributed under the License is distributed on an "AS IS" BASIS,
WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
See the License for the specific language governing permissions and
limitations under the License.
*/

"use strict";

// Requires <script src="common.js">

const IS_CHROMIUM = !!chrome.runtime.getManifest().background.service_worker;
const ALL_URLS = "<all_urls>";

// Partial code from ipvfoobar.
// -- hostnames & asn lookups --
window.dnsCache = {
  hosts: {},
  asns: {}
}

// Snip domains longer than this, to avoid horizontal scrolling.
const LONG_DOMAIN = 40; // Config option maybe?
function snipDomainName(domain){
  if (domain.length > LONG_DOMAIN) {
    return makeSnippedText(domain, Math.floor(LONG_DOMAIN / 2));
  } else {
    return document.createTextNode(domain);
  }
}

// helpers for buttons
const getDomain = host => {
  return psl.parse(host)?.domain;
}

function getWhois(domain) {
  // more tlds?
  if (domain.endsWith(".cz")) return "https://www.nic.cz/whois/domain/" + encodeURIComponent(getDomain(domain));
  return "https://who.is/whois/" + encodeURIComponent(getDomain(domain));
}

function addBtn(url, letter, title, utilsTd, extraClass = "") {
  const btn = document.createElement("a");
  btn.href = url;
  btn.textContent = letter;
  btn.target = "_blank";
  btn.className = `pbtn ${extraClass}`.trim();
  btn.title = title;
  utilsTd.appendChild(btn);
}

// Clipboard copy helpers
let toastTimer = null;
function showToast(msg) {
  const toast = document.getElementById("copy_toast");
  if (!toast) return;
  toast.innerHTML = `<span style="font-size:12px;">✅</span> <span>${msg}</span>`;
  toast.classList.add("show");
  clearTimeout(toastTimer);
  toastTimer = setTimeout(() => {
    toast.classList.remove("show");
  }, 1500);
}

function copyToClipboard(text, message = "Copied to clipboard!") {
  if (!text || text === "(no address)") return;
  if (navigator.clipboard && navigator.clipboard.writeText) {
    navigator.clipboard.writeText(text).then(() => {
      showToast(message);
    }).catch(() => {
      fallbackCopy(text, message);
    });
  } else {
    fallbackCopy(text, message);
  }
}

function fallbackCopy(text, message) {
  const ta = document.createElement("textarea");
  ta.value = text;
  ta.style.position = "fixed";
  ta.style.opacity = "0";
  document.body.appendChild(ta);
  ta.focus();
  ta.select();
  try {
    document.execCommand("copy");
    showToast(message);
  } catch (err) {
    console.error("Copy failed", err);
  }
  document.body.removeChild(ta);
}

function addCopyBtn(textToCopy, letter, title, utilsTd) {
  const btn = document.createElement("button");
  btn.type = "button";
  btn.textContent = letter;
  btn.className = "pbtn btn-copy";
  btn.title = title;
  btn.onclick = (e) => {
    e.preventDefault();
    e.stopPropagation();
    copyToClipboard(textToCopy, `Copied IP: ${textToCopy}`);
    btn.textContent = "✓";
    btn.style.color = "#00d26a";
    setTimeout(() => {
      btn.textContent = letter;
      btn.style.color = "";
    }, 1200);
  };
  utilsTd.appendChild(btn);
}

let currentSearchQuery = "";
let currentFilterType = "all";

function updateStats() {
  const rows = table ? table.querySelectorAll("tr") : [];
  let v4 = 0;
  let v6 = 0;
  const uniqueDomains = new Set();
  let visibleCount = 0;

  for (const tr of rows) {
    if (tr._domain) {
      uniqueDomains.add(tr._domain);
      if (tr._version === "4") v4++;
      else if (tr._version === "6") v6++;
      if (tr.style.display !== "none") visibleCount++;
    }
  }
  const total = uniqueDomains.size;

  const statTotal = document.getElementById("stat_total");
  const statV4 = document.getElementById("stat_v4");
  const statV6 = document.getElementById("stat_v6");

  if (statTotal) {
    if (currentSearchQuery || currentFilterType !== "all") {
      statTotal.textContent = `${visibleCount}/${total} shown`;
    } else {
      statTotal.textContent = `${total} domain${total === 1 ? "" : "s"}`;
    }
  }
  if (statV4) statV4.textContent = `${v4} v4`;
  if (statV6) statV6.textContent = `${v6} v6`;
}

function applyFilter() {
  const rows = table ? table.querySelectorAll("tr") : [];
  let visibleCount = 0;
  const q = currentSearchQuery.toLowerCase();

  for (const tr of rows) {
    let matchFilter = true;
    if (currentFilterType === "4" && tr._version !== "4") {
      matchFilter = false;
    } else if (currentFilterType === "6" && tr._version !== "6") {
      matchFilter = false;
    }

    let matchSearch = true;
    if (q) {
      const d = (tr._domain || "").toLowerCase();
      const a = (tr._addr || "").toLowerCase();
      const h = (tr._hostname || "").toLowerCase();
      const asn = (tr._asn || "").toLowerCase();
      if (!d.includes(q) && !a.includes(q) && !h.includes(q) && !asn.includes(q)) {
        matchSearch = false;
      }
    }

    if (matchFilter && matchSearch) {
      tr.style.display = "";
      visibleCount++;
    } else {
      tr.style.display = "none";
    }
  }

  const noResults = document.getElementById("no_results");
  if (noResults) {
    if (visibleCount === 0 && rows.length > 0) {
      noResults.style.display = "block";
    } else {
      noResults.style.display = "none";
    }
  }
  updateStats();
}

function copyAllIPs() {
  const ips = new Set();
  const rows = table?.querySelectorAll("tr") || [];
  for (const tr of rows) {
    if (tr.style.display === "none") continue;
    const addr = tr._addr;
    if (addr && addr !== "(no address)" && addr !== "null::/96") {
      ips.add(addr);
    }
  }
  if (ips.size === 0) {
    showToast("No IP addresses found");
    return;
  }
  const text = Array.from(ips).join("\n");
  copyToClipboard(text, `Copied ${ips.size} IP${ips.size > 1 ? "s" : ""}!`);
}

function copyTableAsTSV() {
  const rows = table ? table.querySelectorAll("tr") : [];
  if (!rows || rows.length === 0) {
    showToast("No data to copy");
    return;
  }

  const lines = ["Domain\tAddress\tVersion\tHostname\tASN"];
  let count = 0;
  for (const tr of rows) {
    if (tr.style.display === "none") continue;
    const domain = tr._domain || "";
    const addr = tr._addr || "";
    const version = tr._version ? `IPv${tr._version}` : "";
    const hostname = tr._hostname || "";
    const asn = tr._asn || "";
    lines.push(`${domain}\t${addr}\t${version}\t${hostname}\t${asn}`);
    count++;
  }

  if (count === 0) {
    showToast("No visible rows to copy");
    return;
  }

  copyToClipboard(lines.join("\n"), `Copied ${count} rows (TSV) to clipboard!`);
}

function copyTableAsJSON() {
  const rows = table ? table.querySelectorAll("tr") : [];
  if (!rows || rows.length === 0) {
    showToast("No data to copy");
    return;
  }

  const data = [];
  for (const tr of rows) {
    if (tr.style.display === "none") continue;
    data.push({
      domain: tr._domain || "",
      address: tr._addr || "",
      version: tr._version ? `IPv${tr._version}` : "",
      hostname: tr._hostname || "",
      asn: tr._asn || ""
    });
  }

  if (data.length === 0) {
    showToast("No visible rows to copy");
    return;
  }

  copyToClipboard(JSON.stringify(data, null, 2), `Copied ${data.length} items (JSON)!`);
}

// Theme Toggle (Auto -> Dark -> Light -> Auto)
function initThemeToggle() {
  const btn = document.getElementById("theme_toggle_btn");
  if (!btn) return;

  function updateThemeUI(theme) {
    if (theme === "dark") {
      document.documentElement.setAttribute("data-theme", "dark");
      btn.textContent = "🌙 Dark";
      btn.title = "Theme: Dark. Click for Light.";
    } else if (theme === "light") {
      document.documentElement.setAttribute("data-theme", "light");
      btn.textContent = "☀️ Light";
      btn.title = "Theme: Light. Click for Auto.";
    } else {
      document.documentElement.removeAttribute("data-theme");
      btn.textContent = "⚡ Auto";
      btn.title = "Theme: Auto (follows system). Click for Dark.";
    }
  }

  const currentTheme = new URLSearchParams(window.location.search).get("theme") || localStorage.getItem("preferred_theme") || "auto";
  updateThemeUI(currentTheme);

  btn.addEventListener("click", () => {
    const cur = localStorage.getItem("preferred_theme") || "auto";
    let next = "dark";
    if (cur === "dark") next = "light";
    else if (cur === "light") next = "auto";
    else next = "dark";

    try {
      if (next === "auto") {
        localStorage.removeItem("preferred_theme");
      } else {
        localStorage.setItem("preferred_theme", next);
      }
    } catch (e) {}

    updateThemeUI(next);
    showToast(`Theme: ${next.toUpperCase()}`);
  });
}

const tabId = window.location.hash.substr(1);

let table = null;
let gSawHttpGt1 = false;

window.onload = async function() {
  initThemeToggle();
  table = document.getElementById("addr_table");
  table.onmousedown = handleMouseDown;

  // Search & Filter input
  const searchInput = document.getElementById("search_input");
  const searchClear = document.getElementById("search_clear");
  const searchKbd = document.getElementById("search_kbd");
  if (searchInput) {
    searchInput.addEventListener("input", () => {
      currentSearchQuery = searchInput.value.trim().toLowerCase();
      if (searchClear) {
        searchClear.style.display = currentSearchQuery ? "block" : "none";
      }
      if (searchKbd) {
        searchKbd.style.display = currentSearchQuery ? "none" : "block";
      }
      applyFilter();
    });
    searchInput.addEventListener("focus", () => {
      if (searchKbd) searchKbd.style.display = "none";
    });
    searchInput.addEventListener("blur", () => {
      if (searchKbd && !searchInput.value) searchKbd.style.display = "block";
    });
  }
  if (searchClear) {
    searchClear.addEventListener("click", () => {
      if (searchInput) {
        searchInput.value = "";
        currentSearchQuery = "";
        searchClear.style.display = "none";
        if (searchKbd) searchKbd.style.display = "block";
        searchInput.focus();
        applyFilter();
      }
    });
  }

  // Keyboard shortcut listener (/ or Ctrl+F to search, Escape to reset)
  window.addEventListener("keydown", (e) => {
    if ((e.key === "/" && document.activeElement !== searchInput) || (e.ctrlKey && e.key.toLowerCase() === "f")) {
      e.preventDefault();
      if (searchInput) {
        searchInput.focus();
        searchInput.select();
      }
    } else if (e.key === "Escape") {
      if (searchInput && searchInput.value) {
        searchInput.value = "";
        currentSearchQuery = "";
        if (searchClear) searchClear.style.display = "none";
        if (searchKbd) searchKbd.style.display = "block";
        applyFilter();
      }
    }
  });

  // Filter Pills (All / IPv4 / IPv6)
  const pills = document.querySelectorAll(".filter-pill");
  pills.forEach((pill) => {
    pill.addEventListener("click", () => {
      pills.forEach((p) => p.classList.remove("active"));
      pill.classList.add("active");
      currentFilterType = pill.getAttribute("data-filter") || "all";
      applyFilter();
    });
  });

  // Footer Toolbar buttons
  const copyAllBtn = document.getElementById("copy_all_btn");
  if (copyAllBtn) {
    copyAllBtn.onclick = (e) => {
      e.preventDefault();
      copyAllIPs();
    };
  }

  const copyTableBtn = document.getElementById("copy_table_btn");
  if (copyTableBtn) {
    copyTableBtn.onclick = (e) => {
      e.preventDefault();
      copyTableAsTSV();
    };
  }

  const copyJsonBtn = document.getElementById("copy_json_btn");
  if (copyJsonBtn) {
    copyJsonBtn.onclick = (e) => {
      e.preventDefault();
      copyTableAsJSON();
    };
  }

  if (IS_MOBILE) {
    document.getElementById("mobile_footer").style.display = "flex";

    document.addEventListener("selectionchange", redrawLookupBubble);
    const resizeObserver = new ResizeObserver(redrawLookupBubble);
    resizeObserver.observe(table);
  }
  if (/^[0-9]+$/.test(tabId)) {
    await beg();
    connectToExtension();
  } else if (tabId) {
    throw new Error(`Bad tabId: ${tabId}`);
  } else {
    console.log("No tabId, using test table");
    const ptr_gh = "4.121.82.140.in-addr.arpa";
    window.dnsCache.hosts[ptr_gh] = "lb-140-82-121-4-fra.github.com";
    const o_gh = "4.121.82.140.origin.asn.cymru.com";
    window.dnsCache.asns[o_gh] = "AS36459 GITHUB, US";

    const ptr_cdn = "153.108.199.185.in-addr.arpa";
    window.dnsCache.hosts[ptr_cdn] = "cdn-185-199-108-153.github.com";
    const o_cdn = "153.108.199.185.origin.asn.cymru.com";
    window.dnsCache.asns[o_cdn] = "AS54113 FASTLY, US";

    const ptr_goog = full_IPv6("2607:f8b0:4004:800::200e").replaceAll(":", "").split("").reverse().join(".") + ".ip6.arpa";
    window.dnsCache.hosts[ptr_goog] = "iad66s02-in-x0e.1e100.net";
    const o_goog = full_IPv6("2607:f8b0:4004:800::200e").replaceAll(":", "").split("").reverse().join(".") + ".origin6.asn.cymru.com";
    window.dnsCache.asns[o_goog] = "AS15169 GOOGLE, US";

    const ptr_cf = full_IPv6("2606:4700::6811:d159").replaceAll(":", "").split("").reverse().join(".") + ".ip6.arpa";
    window.dnsCache.hosts[ptr_cf] = "cloudflare.com";
    const o_cf = full_IPv6("2606:4700::6811:d159").replaceAll(":", "").split("").reverse().join(".") + ".origin6.asn.cymru.com";
    window.dnsCache.asns[o_cf] = "AS13335 CLOUDFLARENET, US";

    const ptr_cached = full_IPv6("2001:db8::f00").replaceAll(":", "").split("").reverse().join(".") + ".ip6.arpa";
    window.dnsCache.hosts[ptr_cached] = false;
    const o_cached = full_IPv6("2001:db8::f00").replaceAll(":", "").split("").reverse().join(".") + ".origin6.asn.cymru.com";
    window.dnsCache.asns[o_cached] = false;

    const TEST_TUPLES = [
      ["github.com", "140.82.121.4", "4", DFLAG_H2 | DFLAG_CONNECTED],
      ["assets-cdn.github.com", "185.199.108.153", "4", DFLAG_H2 | DFLAG_CONNECTED],
      ["google.com", "2607:f8b0:4004:800::200e", "6", DFLAG_H3 | DFLAG_CONNECTED],
      ["cdnjs.cloudflare.com", "2606:4700::6811:d159", "6", DFLAG_H3 | DFLAG_CONNECTED],
      ["cached.example.com", "2001:db8::f00", "6", DFLAG_H3 | AFLAG_CACHE]
    ];
    pushAll(TEST_TUPLES, "646", REGULAR_COLOR, 0, true);
  }
};

// Monitor for dark mode updates.
const darkModeQuery = window.matchMedia('(prefers-color-scheme: dark)');
let darkMode = darkModeQuery.matches;
darkModeQuery.addEventListener("change", async (event) => {
  darkMode = event.matches;
  await optionsReady;
  if (lastColor) {
    setColorIsDarkMode(lastColor, darkMode);
  }
});

async function beg() {
  const p = await chrome.permissions.getAll();
  for (const origin of p.origins) {
    if (origin == ALL_URLS) {
      return;  // We already have permission.
    }
  }
  const button = document.getElementById("beg");
  button.style.display = "block";  // visible
  button.addEventListener("click", async () => {
    // We need to close the popup before awaiting, otherwise
    // Firefox (at least version 116 on Windows) renders the
    // permission dialog underneath the popup.
    const promise = chrome.permissions.request({origins: [ALL_URLS]});
    window.close();
    await promise;
  });
}

function redrawLookupBubble() {
  const bubble = document.getElementById("lookup_bubble");
  const sel = window.getSelection();
  const text = sel.toString();
  const menuTitle = lookupMenuTitle(text);
  const href = selectionToLookupUrl(text)?.href;

  if (!(menuTitle && href)) {
    bubble.style.display = "none";
    return;
  }

  const link = document.getElementById("lookup_link");
  link.textContent = menuTitle;
  link.href = href;

  const selRect = sel.getRangeAt(0).getBoundingClientRect();
  const tableRect = table.getBoundingClientRect();

  bubble.style.display = "block";
  bubble.style.top = `${selRect.bottom + window.scrollY + 5}px`;
  bubble.style.setProperty('--bubble-left', `${selRect.left - 10}px`);
  bubble.style.setProperty('--table-left', `${tableRect.left}px`);
  bubble.style.setProperty('--table-width', `${tableRect.width}px`);

  const bubbleRect = bubble.getBoundingClientRect();
  bubble.style.setProperty('--bubble-width', `${bubbleRect.width}px`);
}

function connectToExtension() {
  const port = chrome.runtime.connect(null, {name: tabId});
  port.onMessage.addListener((msg) => {
    document.bgColor = "";
    //console.log("onMessage", msg.cmd, msg);
    switch (msg.cmd) {
      case "pushAll":
        return pushAll(msg.tuples, msg.pattern, msg.color, msg.spillCount, msg.sawHttpGt1);
      case "pushOne":
        return pushOne(msg.tuple);
      case "pushPattern":
        return pushPattern(msg.pattern, msg.color);
      case "pushSpillCount":
        return pushSpillCount(msg.spillCount);
      case "shake":
        return shake();
    }
  });

  port.onDisconnect.addListener(() => {
    document.bgColor = "lightpink";
    setTimeout(connectToExtension, 1);
  });
}

// Clear the table, and fill it with new data.
function pushAll(tuples, pattern, color, spillCount, sawHttpGt1) {
  gSawHttpGt1 = sawHttpGt1;
  removeChildren(table);
  for (let i = 0; i < tuples.length; i++) {
    table.appendChild(makeRow(i == 0, tuples[i]));
  }
  pushPattern(pattern, color);
  pushSpillCount(spillCount);
  updateStats();
  applyFilter();
}

// Insert or update a single table row.
function pushOne(tuple) {
  const domain = tuple[0];
  let insertHere = null;
  let isFirst = true;
  for (let tr = table.firstChild; tr; tr = tr.nextSibling) {
    if (tr._domain == domain) {
      // Found an exact match.  Update the row.
      minimalCopy(makeRow(isFirst, tuple), tr);
      updateStats();
      applyFilter();
      return;
    }
    if (isFirst) {
      isFirst = false;
    } else if (tr._domain > domain) {
      insertHere = tr;
      break;
    }
  }
  // No exact match.  Insert the row in alphabetical order.
  table.insertBefore(makeRow(false, tuple), insertHere);
  updateStats();
  applyFilter();
  if (IS_MOBILE) {
    zoomHack();
  } else {
    scrollbarHack();
  }
}

let lastPattern = "";
let lastColor = "";  // regular/incognito color scheme
function pushPattern(pattern, color) {
  if (lastColor != color) {
    lastColor = color;
    setColorIsDarkMode(lastColor, darkMode);
  }
  if (!IS_MOBILE) {
    return;
  }
  if (lastPattern != pattern) {
    lastPattern = pattern;
  } else {
    return;
  }
  for (const color of ["darkfg", "lightfg"]) {
    const img = document.getElementById(`pattern_icon_${color}`);
    img.src = iconPath(pattern, 32, color);
  }
}

// Count must be a number.
function pushSpillCount(count) {
  document.getElementById("spill_count_container").style.display =
      count == 0 ? "none" : "block";
  removeChildren(document.getElementById("spill_count")).appendChild(
      document.createTextNode(count));
  if (IS_MOBILE) {
    zoomHack();
  } else {
    scrollbarHack();
  }
}

// Shake the content (for 500ms) to signal an error.
function shake() {
  document.body.className = "shake";
  setTimeout(function() {
    document.body.className = "";
  }, 600);
}

// On mobile, zoom in so the table fills the viewport.
function zoomHack() {
  // This value is actually a bit smaller than we want,
  // but apparently a too-narrow viewport results in a best-fit zoom.
  const tableWidth = document.querySelector('table').offsetWidth;
  document.querySelector('meta[name="viewport"]').setAttribute('content', `width=${tableWidth}`);

  // Leave room to the right for the text selection handle,
  // to prevent jittery zooming if the user selects an IP address.
  // 8% of the table width seems reasonable.
  table.style.setProperty('--cache-min-width', `${tableWidth * 0.08}px`);
}

// Workaround for https://bugzilla.mozilla.org/show_bug.cgi?id=1395025
let redrawn = false;
function scrollbarHack() {
  if (IS_CHROMIUM) {
    return;  // nothing to do on Chrome.
  }
  setTimeout(() => {
    const e = document.documentElement;
    if (e.scrollHeight > e.clientHeight) {
      document.body.style.paddingRight = '20px';
    } else if (!redrawn) {
      document.body.classList.toggle('force-redraw');
      redrawn = true;
    }
  }, 200);
}

// Copy the contents of src into dst, making minimal changes.
function minimalCopy(src, dst) {
  dst.className = src.className;
  dst._domain = src._domain;
  dst._addr = src._addr;
  dst._version = src._version;
  dst._hostname = src._hostname;
  dst._asn = src._asn;
  for (let s = src.firstChild, d = dst.firstChild, sNext, dNext;
       s && d;
       s = sNext, d = dNext) {
    sNext = s.nextSibling;
    dNext = d.nextSibling;
    // First, sync up the class names.
    d.className = s.className = s.className;
    // Only replace the whole node if something changes.
    // That way, we avoid stomping on the user's selected text.
    if (!d.isEqualNode(s)) {
      dst.replaceChild(s, d);
    }
  }
}

function makeImg(src, title) {
  const img = document.createElement("img");
  img.src = src;
  img.title = title;
  return img;
}

function makeHttpImg(flags) {
  if (flags & DFLAG_NO_TLS) {
    return makeImg(
        "gray_unlock.png",
        "Some connections do not use TLS.");
  }
  if (gSawHttpGt1) {
    if (flags & DFLAG_H3) {
      return makeImg(
          "gray_h3.png",
          "HTTP/3 (with TLS) is the max version seen.");
    }
    if (flags & DFLAG_H2) {
      return makeImg(
          "gray_h2.png",
          "HTTP/2 (with TLS) is the max version seen.");
    }
    if (flags & DFLAG_H1) {
      return makeImg(
          "gray_h1.png",
          "HTTP/1.x (with TLS) is the max version seen.");
    }
  } else if (flags & (DFLAG_H1 | DFLAG_H2 | DFLAG_H3)) {
    return makeImg(
        "gray_lock.png",
        "All connections use TLS.");
  }
  return makeImg(
      "gray_question.png",
      "Failed to parse HTTP status.");
}

function makeSelectMe(...children) {
  const span = document.createElement("span");
  span.className = "selectMe";
  for (const child of children) {
    if (child instanceof Node) {
      span.appendChild(child);
    } else {
      span.appendChild(document.createTextNode(child));
    }
  }
  return span;
}

function makeRow(isFirst, tuple) {
  const domain = tuple[0];
  const addr = tuple[1];
  const version = tuple[2];
  const flags = tuple[3];

  const tr = document.createElement("tr");
  if (isFirst) {
    tr.className = "mainRow";
  }
  tr._domain = domain;
  tr._addr = addr;
  tr._version = version;
  tr._hostname = "";
  tr._asn = "";

  // Build the HTTP icon for the "zeroth" pseudo-column.
  const httpImg = makeHttpImg(flags);
  httpImg.className = "httpImg";

  // Build the "Domain" column.
  const domainTd = document.createElement("td");
  domainTd.appendChild(httpImg);
  domainTd.appendChild(makeSelectMe(
      domain.length > LONG_DOMAIN ? makeSnippedText(domain, Math.floor(LONG_DOMAIN / 2)) : domain));
  domainTd.className = "domainTd";
  domainTd.onclick = handleClick;
  domainTd.oncontextmenu = handleContextMenu;
  domainTd.title = "Click to select, double-click to copy: " + domain;
  domainTd.ondblclick = (e) => {
    e.preventDefault();
    copyToClipboard(domain, `Copied domain: ${domain}`);
  };

  // Build the "Address" column.
  const addrTd = document.createElement("td");
  let addrClass = "";
  switch (version) {
    case "4": addrClass = " ip4"; break;
    case "6": addrClass = " ip6"; break;
  }
  const connectedClass = (flags & DFLAG_CONNECTED) ? " highlight" : "";
  addrTd.className = `addrTd${addrClass}${connectedClass}`;
  const match = addr.match(/^(.*:)(\d+[.]\d+[.]\d+[.]\d+)$/);
  if (match) {
    addrTd.appendChild(makeSelectMe(match[1], makeSelectMe(match[2])));
  } else {
    addrTd.appendChild(makeSelectMe(addr));
  }

  addrTd.onclick = handleClick;
  addrTd.oncontextmenu = handleContextMenu;
  addrTd.title = "Click to select, double-click to copy: " + addr;
  addrTd.ondblclick = (e) => {
    e.preventDefault();
    copyToClipboard(addr, `Copied IP: ${addr}`);
  };

  const metaContainer = document.createElement("div");
  metaContainer.className = "meta-container";

  let hostDiv = null;
  let originDiv = null;

  const hostSpan = document.createElement("span");
  const originSpan = document.createElement("span");

  let ptr;
  let origin;
  if (addr.includes(".")) {
    let dnsName = addr.split(".").reverse().join(".");
    ptr = dnsName + ".in-addr.arpa";
    origin = dnsName + ".origin.asn.cymru.com";
  } else if (addr.includes(":")) {
    let dnsName = full_IPv6(addr).replaceAll(":", "").split("").reverse().join(".");
    ptr = dnsName + ".ip6.arpa";
    origin = dnsName + ".origin6.asn.cymru.com";
  }

  if (ptr) {
    hostDiv = document.createElement("div");
    hostDiv.className = "meta-badge host-badge";
    hostDiv.title = "Double-click to copy PTR hostname";
    hostDiv.ondblclick = (e) => {
      e.preventDefault();
      e.stopPropagation();
      const txt = hostSpan.textContent;
      if (txt && txt !== "resolving...") {
        copyToClipboard(txt, `Copied hostname: ${txt}`);
      }
    };
    const hostIcon = document.createElement("span");
    hostIcon.textContent = "🌐 ";
    hostDiv.appendChild(hostIcon);
    hostDiv.appendChild(hostSpan);
    hostSpan.onclick = handleClick;
    hostSpan.oncontextmenu = handleContextMenu;
    metaContainer.appendChild(hostDiv);

    if (typeof window.dnsCache.hosts[ptr] === "undefined") {
      hostSpan.textContent = "resolving...";
      fetch("https://dns.google/resolve?name=" + ptr + "&type=PTR").then(res => res.json()).then(res => {
        hostSpan.textContent = '';
        let hasFoundHostname = false;
        if (res.Answer){
          for (let answer of res.Answer){
            if (answer.data && answer.type === 12) { // PTR
              window.dnsCache.hosts[ptr] = answer.data.slice(0, -1);
              tr._hostname = window.dnsCache.hosts[ptr];
              hostSpan.appendChild(snipDomainName(window.dnsCache.hosts[ptr]));
              hasFoundHostname = true;
              break;
            }
          }
        }
        if (!hasFoundHostname){
          window.dnsCache.hosts[ptr] = false;
          hostDiv.remove();
          if (!metaContainer.hasChildNodes()) metaContainer.remove();
        }
      }).catch(() => {
        if (hostDiv) hostDiv.remove();
        if (!metaContainer.hasChildNodes()) metaContainer.remove();
      });
    } else {
      hostSpan.textContent = '';
      if (window.dnsCache.hosts[ptr]) {
        tr._hostname = window.dnsCache.hosts[ptr];
        hostSpan.appendChild(snipDomainName(window.dnsCache.hosts[ptr]));
      } else {
        hostDiv.remove();
        if (!metaContainer.hasChildNodes()) metaContainer.remove();
      }
    }
  }

  if (origin) {
    originDiv = document.createElement("div");
    originDiv.className = "meta-badge asn-badge";
    originDiv.title = "Double-click to copy ASN info";
    originDiv.ondblclick = (e) => {
      e.preventDefault();
      e.stopPropagation();
      const txt = originSpan.textContent;
      if (txt && txt !== "fetching...") {
        copyToClipboard(txt, `Copied ASN: ${txt}`);
      }
    };
    const asnIcon = document.createElement("span");
    asnIcon.textContent = "🏷️ ";
    originDiv.appendChild(asnIcon);
    originDiv.appendChild(originSpan);
    originSpan.onclick = handleClick;
    originSpan.oncontextmenu = handleContextMenu;
    metaContainer.appendChild(originDiv);

    if (typeof window.dnsCache.asns[origin] === "undefined") {
      originSpan.textContent = "fetching...";
      fetch("https://dns.google/resolve?name=" + origin + "&type=TXT").then(res => res.json()).then(async res => {
        if (res.Answer && res.Answer[0] && res.Answer[0].data) {
          window.dnsCache.asns[origin] = "AS" + res.Answer[0].data.split('|')[0].slice(0, -1);
          let res2 = await fetch("https://dns.google/resolve?name=" + window.dnsCache.asns[origin] + ".asn.cymru.com&type=TXT").then(res => res.json());
          if (res2.Answer && res2.Answer[0] && res2.Answer[0].data){
            let ans = res2.Answer[0].data.split(' |');
            window.dnsCache.asns[origin] = `AS${ans[0]} ${ans[4].split(' ')[1].split(',')[0]}, ${ans[1]}`;
            tr._asn = window.dnsCache.asns[origin];
            originSpan.textContent = window.dnsCache.asns[origin];
          }
        } else {
          window.dnsCache.asns[origin] = false;
          originDiv.remove();
          if (!metaContainer.hasChildNodes()) metaContainer.remove();
        }
      }).catch(() => {
        if (originDiv) originDiv.remove();
        if (!metaContainer.hasChildNodes()) metaContainer.remove();
      });
    } else {
      if (window.dnsCache.asns[origin]) {
        tr._asn = window.dnsCache.asns[origin];
        originSpan.textContent = window.dnsCache.asns[origin];
      } else {
        originDiv.remove();
        if (!metaContainer.hasChildNodes()) metaContainer.remove();
      }
    }
  }

  if (metaContainer.hasChildNodes()) {
    addrTd.appendChild(metaContainer);
  }

  const utilsTd = document.createElement("td");
  utilsTd.className = "utilsTd";

  // Copy IP Button
  addCopyBtn(addr, "C", "Copy IP (" + addr + ")", utilsTd);

  // Quick lookup buttons
  addBtn(getWhois(domain), "W", "WHOIS", utilsTd, "pbtn-w");
  addBtn("https://search.arin.net/rdap/?query=" + encodeURIComponent(addr), "A", "ARIN", utilsTd, "pbtn-a");
  addBtn("https://apps.db.ripe.net/db-web-ui/query?searchtext=" + encodeURIComponent(addr), "R", "RIPE", utilsTd, "pbtn-r");
  addBtn("https://ipinfo.io/" + addr, "I", "IPInfo", utilsTd, "pbtn-i");
  addBtn("https://bgp.he.net/ip/" + encodeURIComponent(addr), "H", "Hurricane Electric (BGP)", utilsTd, "pbtn-h");
  addBtn("https://bgp.tools/prefix/" + addr, "B", "BGP.Tools", utilsTd, "pbtn-b");

  // Build the (possibly invisible) "WebSocket/Cached" column.
  const cacheTd = document.createElement("td");
  cacheTd.className = `cacheTd${connectedClass}`;
  if (flags & DFLAG_WEBSOCKET) {
    cacheTd.appendChild(
        makeImg("websocket.png", "WebSocket handshake; connection may still be active."));
    cacheTd.style.paddingLeft = '6pt';
  } else if (flags & AFLAG_PREFETCH) {
    cacheTd.appendChild(
        makeImg("prefetch.png", "Prefetched request; may be proxied."));
    cacheTd.style.paddingLeft = '6pt';
  } else if (flags & AFLAG_WORKER) {
    cacheTd.appendChild(
        makeImg("serviceworker.png", "Service Worker request; possibly from a different tab."));
    cacheTd.style.paddingLeft = '6pt';
  } else if (flags & AFLAG_CACHE) {
    cacheTd.appendChild(
        makeImg("cached_arrow.png", "Data from cached requests only."));
    cacheTd.style.paddingLeft = '6pt';
  } else {
    cacheTd.style.paddingLeft = '0';
  }

  tr.appendChild(domainTd);
  tr.appendChild(addrTd);
  tr.appendChild(cacheTd);
  tr.appendChild(utilsTd);
  return tr;
}

// Given a long domain name, generate "prefix...suffix".  When the user
// clicks "...", all domains are expanded.  The CSS is tricky because
// we want the original domain to remain intact for clipboard purposes.
function makeSnippedText(domain, keep) {
  const prefix = domain.substr(0, keep);
  const snipped = domain.substr(keep, domain.length - 2 * keep);
  const suffix = domain.substr(domain.length - keep);
  const f = document.createDocumentFragment();

  // Add prefix text.
  f.appendChild(document.createTextNode(prefix));

  // Add snipped text, invisible but copyable.
  let snippedText = document.createElement("span");
  snippedText.className = "snippedTextInvisible";
  snippedText.textContent = snipped;
  f.appendChild(snippedText);

  // Add clickable "..." image.
  const snipImg = makeImg("snip.png", "");
  snipImg.className = "snipImg";
  const snipLink = document.createElement("a");
  snipLink.className = "snipLinkInvisible snipLinkVisible";
  snipLink.href = "#";
  snipLink.addEventListener("click", unsnipAll);
  snipLink.appendChild(snipImg);
  f.appendChild(snipLink);

  // Add suffix text.
  f.appendChild(document.createTextNode(suffix));
  return f;
}

function unsnipAll(event) {
  event.preventDefault();
  removeStyles(".snippedTextInvisible", ".snipLinkVisible");
}

function removeStyles(...selectors) {
  const stylesheet = document.styleSheets[0];
  for (const selector of selectors) {
    for (let i = stylesheet.cssRules.length - 1; i >= 0; i--) {
      const rule = stylesheet.cssRules[i];
      if (rule.selectorText === selector) {
        stylesheet.deleteRule(i);
      }
    }
  }
}

// Mac OS has an annoying feature where right-click selects the current
// "word" (i.e. a useless fragment of the address) before showing a
// context menu.  Detect this by watching for the selection to change
// between consecutive onmousedown and oncontextmenu events.
let oldTimeStamp = 0;
let oldRanges = [];
function handleMouseDown(e) {
  oldTimeStamp = e.timeStamp;
  oldRanges = [];
  const sel = window.getSelection();
  for (let i = 0; i < sel.rangeCount; i++) {
    oldRanges.push(sel.getRangeAt(i));
  }
}

function sameRange(r1, r2) {
  return (r1.compareBoundaryPoints(Range.START_TO_START, r2) == 0 &&
          r1.compareBoundaryPoints(Range.END_TO_END, r2) == 0);
}

function isSpuriousSelection(sel, newTimeStamp) {
  if (newTimeStamp - oldTimeStamp > 10) {
    return false;
  }
  if (sel.rangeCount != oldRanges.length) {
    return true;
  }
  for (let i = 0; i < sel.rangeCount; i++) {
    if (!sameRange(sel.getRangeAt(i), oldRanges[i])) {
      return true;
    }
  }
  return false;
}

function handleContextMenu(e) {
  const sel = window.getSelection();
  if (isSpuriousSelection(sel, e.timeStamp)) {
    sel.removeAllRanges();
  }
  selectAddress(this, e.target, sel);
  return sel;
}

// Find the innermost "selectMe" that the user clicked on directly,
// otherwise find the outermost "selectMe" in the cell.
// This will either select a NAT64 IPv4 suffix, or the entire address.
function findSelectMe(node, target) {
  const range = document.createRange();
  range.selectNodeContents(
      target?.closest(".selectMe") || node.querySelector(".selectMe"));
  return range;
}

function handleClick(e) {
  const sel = window.getSelection();

  // If the user clicked an already-selected address, deselect it.
  // Don't check timeStamp because it depends how long they held the button.
  if (e.detail == 1 && oldRanges.length == 1) {
    if (sameRange(findSelectMe(this, e.target), oldRanges[0])) {
      sel.removeAllRanges();
      return;
    }
  }

  selectAddress(this, e.target, sel);
}

// If the user hasn't manually selected part of the address, then select
// the whole thing, to make copying easier.
function selectAddress(node, target, sel) {
  if (sel.isCollapsed || !sel.containsNode(node, true)) {
    sel.removeAllRanges();
    sel.addRange(findSelectMe(node, target));
  }
}

function full_IPv6(ip_string) {
  // replace ipv4 address if any
  var ipv4 = ip_string.match(/(.*:)([0-9]+\.[0-9]+\.[0-9]+\.[0-9]+$)/);
  if (ipv4) {
    var ip_string = ipv4[1];
    ipv4 = ipv4[2].match(/[0-9]+/g);
    for (var i = 0; i < 4; i++) {
      var byte = parseInt(ipv4[i], 10);
      ipv4[i] = ("0" + byte.toString(16)).substr(-2);
    }
    ip_string += ipv4[0] + ipv4[1] + ':' + ipv4[2] + ipv4[3];
  }

  // take care of leading and trailing ::
  ip_string = ip_string.replace(/^:|:$/g, '');

  var ipv6 = ip_string.split(':');

  for (var i = 0; i < ipv6.length; i++) {
    var hex = ipv6[i];
    if (hex != "") {
      // normalize leading zeros
      ipv6[i] = ("0000" + hex).substr(-4);
    }
    else {
      // normalize grouped zeros ::
      hex = [];
      for (var j = ipv6.length; j <= 8; j++) {
        hex.push('0000');
      }
      ipv6[i] = hex.join(':');
    }
  }

  return ipv6.join(':');
}