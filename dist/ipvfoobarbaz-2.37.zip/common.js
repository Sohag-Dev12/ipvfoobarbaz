/*
Copyright (C) 2017  Paul Marks  http://www.pmarks.net/

Licensed under the Apache License, Version 2.0 (the "License");
you may not use this file except in compliance with the License.
You may obtain a copy of the License at

    http://www.apache.org/licenses/LICENSE-2.0

Unless required by applicable law or agreed to in writing, software
distributed under the License is distributed on an "AS IS" BASIS,
WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
See the License for the specific language governing permissions and
limitations under the License.
*/

"use strict";

// Requires <script src="iputil.js">

const IS_MOBILE = /\bMobile\b/.test(navigator.userAgent);

// Domain flags are bitwise-OR'd across all connections to a domain.
const DFLAG_MASK = 0xFF00;
const DFLAG_NO_TLS = 0x100;  // Unencrypted HTTP
const DFLAG_H1 = 0x200;      // HTTP/1.x with TLS
const DFLAG_H2 = 0x400;      // HTTP/2.x with TLS
const DFLAG_H3 = 0x800;      // HTTP/3.x with TLS
const DFLAG_CONNECTED = 0x1000;
const DFLAG_WEBSOCKET = 0x2000;
const DFLAG_NOTWORKER = 0x4000;  // from a tab, not a service worker

// Address flags refer to a specific connection, and are used to prioritize
// which address is shown to the user.  The lowest numerical value wins.
const AFLAG_MASK = 0xFF;
const AFLAG_PREFETCH = 0x4;
const AFLAG_WORKER = 0x2;
const AFLAG_CACHE = 0x1;

const IPV4_ONLY_DOMAINS = new Set(["ipv4.google.com", "ipv4.icanhazip.com", "ipv4.whatismyip.akamai.com"]);

// Returns an Object with no default properties.
function newMap() {
  return Object.create(null);
}

function clearMap(m) {
  for (const k of Object.keys(m)) {
    delete m[k];
  }
}

function sleep(ms) {
  return new Promise(resolve => setTimeout(resolve, ms));
}

function removeChildren(n) {
  while (n.hasChildNodes()) {
    n.removeChild(n.lastChild);
  }
  return n;
}

function iconPath(pattern, size, color) {
  const filebase = `${color}${size}_${pattern.replaceAll('?', 'q')}`;
  if (!/^(lightfg|darkfg)(16|32)_[46q](|4|6|46)$/.test(filebase)) {
    throw new Error(`Unexpected icon format: ${filebase}`);
  }
  return `generated_icons/${filebase}.png`;
}

const REGULAR_COLOR = "regularColorScheme";
const INCOGNITO_COLOR = "incognitoColorScheme";
const SAW_HTTP_GT_1 = "sawHttpGt1";

const LOOKUP_PROVIDER = "lookupProvider";
const CUSTOM_PROVIDER = "customProvider:";
const CUSTOM_PROVIDER_DOMAIN = CUSTOM_PROVIDER + "domain";
const CUSTOM_PROVIDER_IP = CUSTOM_PROVIDER + "ip";

// "$" is a placeholder for the user's selected domain or IP address.
const LOOKUP_PROVIDERS = {
  "bgp.he.net": {
    domain: "https://bgp.he.net/dns/$",
    ip: "https://bgp.he.net/ip/$",
  },
  "info.addr.tools": {
    domain: "https://info.addr.tools/$",
    ip: "https://info.addr.tools/$",
  },
  "ipinfo.io": {
    domain: "",
    ip: "https://ipinfo.io/$",
  },
};

function parseLookupUrl(pattern, placeholder="") {
  pattern = pattern?.trim();
  if (!pattern) {
    return null;
  }
  if (!/^https:[/][/][^/$]+[/].*[$]/.test(pattern)) {
    throw new Error("malformed");
  }
  return new URL(pattern.replaceAll("$", placeholder));  // may throw
}
function maybeLookupUrl(pattern, placeholder="") {
  try {
    return parseLookupUrl(pattern, placeholder);
  } catch {
    return null;
  }
}

// Distinguish IP address and domain name characters.
// Note that IP6_CHARS must not match "beef.de"
const IP4_CHARS = /^[0-9.]+$/;
const IP6_CHARS = /^[0-9A-Fa-f]*:[0-9A-Fa-f:.]*$/;
const DNS_CHARS = /^[0-9A-Za-z._-]+$/;

function selectionToLookupUrl(text) {
  let selectionType = "";
  // Remember that IP must be evaluated before DNS.
  if (IP4_CHARS.test(text) || IP6_CHARS.test(text)) {
    selectionType = "ip";
    // bgp.he.net doesn't support dotted IPv6 addresses.
    text = reformatForNAT64(text, false);
  } else if (DNS_CHARS.test(text)) {
    selectionType = "domain";
  } else {
    return null;
  }
  const provider = options[LOOKUP_PROVIDER];
  const pattern = (provider == "custom") ?
      options[`${CUSTOM_PROVIDER}${selectionType}`] :
      LOOKUP_PROVIDERS[provider]?.[selectionType];
  return maybeLookupUrl(pattern, text);
}

// Generate "Lookup on [provider]" string for whatever text is selected.
// If unsure, caller should provide an example domain and IP address.
function lookupMenuTitle(...selectionTexts) {
  let providerText = options[LOOKUP_PROVIDER];
  if (providerText == "custom") {
    const hostnames = selectionTexts
        .map(text => selectionToLookupUrl(text)?.hostname)
        .filter(Boolean);
    providerText = [...new Set(hostnames)].join(" | ");
  }
  if (providerText) {
    return `Lookup on ${providerText}`;
  } else {
    return "";
  }
}

const NAT64_KEY = "nat64/";
const NAT64_VALIDATE = /^nat64\/[0-9a-f]{24}$/;
const NAT64_DEFAULTS = new Set([
  parseIP("::ffff:0:0").slice(0, 96/4),  // For stupid AAAA records
  parseIP("64:ff9b::").slice(0, 96/4),   // RFC 6052
  parseIP("64:ff9b:1::").slice(0, 96/4), // RFC 8215
]);

let _watchOptionsFunc = null;
const DEFAULT_LOCAL_OPTIONS = {
  [REGULAR_COLOR]: "",  // default replaced on first boot.
  [INCOGNITO_COLOR]: "lightfg",
  [SAW_HTTP_GT_1]: false,
};
const DEFAULT_SYNC_OPTIONS = {
  [LOOKUP_PROVIDER]: "bgp.he.net",
  [CUSTOM_PROVIDER_DOMAIN]: "",
  [CUSTOM_PROVIDER_IP]: "",
};
const options = {
  ready: false,
  [NAT64_KEY]: new Set(NAT64_DEFAULTS),
  ...DEFAULT_LOCAL_OPTIONS,
  ...DEFAULT_SYNC_OPTIONS,
};
const optionsReady = (async function() {
  const [localItems, syncItems] = await Promise.all(
      [chrome.storage.local.get(), chrome.storage.sync.get()]);
  for (const [option, value] of Object.entries(localItems)) {
    if (DEFAULT_LOCAL_OPTIONS.hasOwnProperty(option)) {
      options[option] = value;
    }
  }
  for (const [option, value] of Object.entries(syncItems)) {
    if (NAT64_VALIDATE.test(option)) {
      options[NAT64_KEY].add(option.slice(NAT64_KEY.length));
    } else if (DEFAULT_SYNC_OPTIONS.hasOwnProperty(option)) {
      options[option] = value;
    }
  }
  options.ready = true;
  _watchOptionsFunc?.(Object.keys(options));
})();

chrome.storage.local.onChanged.addListener(function(changes) {
  // changes = {option: {oldValue: x, newValue: y}}
  if (!options.ready) return;
  const optionsChanged = [];
  for (const [option, {oldValue, newValue}] of Object.entries(changes)) {
    if (DEFAULT_LOCAL_OPTIONS.hasOwnProperty(option)) {
      if (options[option] != newValue) {
        options[option] = newValue;
        optionsChanged.push(option);
      }
    }
  }
  if (optionsChanged.length) {
    _watchOptionsFunc?.(optionsChanged);
  }
});

chrome.storage.sync.onChanged.addListener(function(changes) {
  // changes = {option: {oldValue: x, newValue: y}}
  if (!options.ready) return;
  const optionsChanged = [];
  for (const [option, {oldValue, newValue}] of Object.entries(changes)) {
    if (NAT64_VALIDATE.test(option)) {
      const packed96 = option.slice(NAT64_KEY.length);
      if (newValue && !options[NAT64_KEY].has(packed96)) {
        options[NAT64_KEY].add(packed96);
      } else if (!newValue && options[NAT64_KEY].has(packed96)) {
        options[NAT64_KEY].delete(packed96);
      } else {
        continue;  // no change
      }
      if (!optionsChanged.includes(NAT64_KEY)) {
        optionsChanged.push(NAT64_KEY);
      }
    } else if (DEFAULT_SYNC_OPTIONS.hasOwnProperty(option)) {
      if (options[option] != newValue) {
        options[option] = newValue;
        optionsChanged.push(option);
      }
    }
  }
  if (optionsChanged.length) {
    _watchOptionsFunc?.(optionsChanged);
  }
});

function watchOptions(f) {
  if (_watchOptionsFunc) throw "redundant watchOptions!";
  _watchOptionsFunc = f;
  if (options.ready) {
    _watchOptionsFunc(Object.keys(options));
  }
}

function setColorIsDarkMode(option, isDarkMode) {
  if (!(option == REGULAR_COLOR || option == INCOGNITO_COLOR)) {
    throw new Error("invalid color scheme", option);
  }
  if (IS_MOBILE && option == INCOGNITO_COLOR) {
    // Firefox for Android, the incognito popup follows the system theme
    // regardless of toolbar color, so just assume dark mode (lightfg).
    // I wonder if there exist edge cases where this assumption is wrong?
    isDarkMode = true;
  }
  const value = isDarkMode ? "lightfg" : "darkfg";
  if (options[option] != value) {
    options[option] = value;
    try {
      chrome.storage.local.set({[option]: value});
    } catch (e) {
      // This happens when testing popup.html standalone.
      console.error(e)
    }
    _watchOptionsFunc?.([option]);
  }
}

// Call this if webRequest reports HTTP/2 or HTTP/3.
// Doesn't work in Chrome: https://issues.chromium.org/issues/41432835
function sawHttpGt1() {
  const o = SAW_HTTP_GT_1;
  if (!options[o]) {
    options[o] = true;
    try {
      chrome.storage.local.set({[o]: true});
    } catch (e) {
      console.error(e)
    }
    // Nothing is currently watching for this.
    _watchOptionsFunc?.([o]);
  }
}

// Users can manually call this function to add a NAT64 prefix from the console.
function addNAT64(ip) {
  if (ip.endsWith("/96")) {
    ip = ip.slice(0, ip.length-3);
  }
  const packed96 = parseIP(ip).slice(0, 96/4);
  addPackedNAT64(packed96);
  return `Added NAT64 prefix ${formatIPv6(packed96)}/96`;
}

function addPackedNAT64(packed96) {
  if (options[NAT64_KEY].has(packed96)) {
    return;
  }
  const key = NAT64_KEY + packed96;
  if (!NAT64_VALIDATE.test(key)) throw "invalid packed96"
  options[NAT64_KEY].add(packed96);
  chrome.storage.sync.set({[key]: 1});
  // NAT64 changes are reported synchronously.  When onChanged fires,
  // our local Set is used for deduplication.
  _watchOptionsFunc?.([NAT64_KEY]);
}

function revertNAT64() {
  let toRemove = [];
  for (const prefix96 of options[NAT64_KEY].keys()) {
    if (!NAT64_DEFAULTS.has(prefix96)) {
      toRemove.push(NAT64_KEY + prefix96);
    }
  }
  options[NAT64_KEY] = new Set(NAT64_DEFAULTS);
  if (toRemove.length) {
    chrome.storage.sync.remove(toRemove);
    // NAT64 changes are reported synchronously.  When onChanged fires,
    // our local Set is used for deduplication.
    _watchOptionsFunc?.([NAT64_KEY]);
  }
}

function reformatForNAT64(addr, doLookup=true) {
  let packed128 = "";
  try {
    packed128 = parseIP(addr);
  } catch {
    return addr;  // no change
  }
  if (packed128.length != 128/4) {
    return addr;  // no change
  }
  const isNAT64 = doLookup && options[NAT64_KEY].has(packed128.slice(0, 96/4));
  return formatIPv6(packed128, /*with_dots=*/isNAT64);
}
